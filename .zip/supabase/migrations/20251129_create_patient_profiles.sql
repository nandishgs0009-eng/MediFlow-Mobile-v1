-- DEPRECATED: This migration is no longer needed
-- The patient profile information is now stored in the existing 'profiles' table
-- See 20251129_update_profiles_table.sql for the updated schema

-- Original attempt to create separate patient_profiles table (UNUSED)
-- Please apply 20251129_update_profiles_table.sql instead

