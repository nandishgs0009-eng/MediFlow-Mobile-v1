/// <reference types="vite/client" />
